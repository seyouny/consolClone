import ItemsCarousel from './ItemsCarousel';

export default ItemsCarousel;
